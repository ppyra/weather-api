Project was created using flex-layout and material angular for prepare layout. The layout is responsive. Application shows 5 cities on the cards and display temperature (converted from Kelvin to Celcius) and wind speed.  After click on "Show the weathre forecast" shows the forecast in the next hours - I set 10 next items from table weather. 
On the list are display temperature, wind speed, time and image form weather api presenting current weather status.
An interceptor handling the error service has been implemented in the application.
I apply unit tests (run by ng test)
and tests end-to-end (e2e) (run by ng e2e)